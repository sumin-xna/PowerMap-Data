# TDMS UV Output Comparator

A small local Streamlit web app for comparing PowerMAP/TDMS UV output files.

## What it extracts

For every dropped `.tdms` file, the app extracts:

- File name
- TDMS name
- Calibration date
- Date of measurement
- Notes
- Serial number
- Model / unit type / range
- UV sample rate
- UVA, UVB, UVC, and UVV energy density in `mJ/cm^2`
- UVA, UVB, UVC, and UVV peak irradiance in `mW/cm^2`

The app shows the comparison table on screen and lets you download one Excel sheet: `tdms_uv_comparison.xlsx`.

## Install

Open a terminal in this folder and run:

```bash
python -m pip install -r requirements.txt
```

## Run

```bash
python -m streamlit run app.py
```

A browser window should open. Drop one or more `.tdms` files into the upload box, then click **Download Excel comparison**.

## Notes

- The app is designed around the PowerMAP II TDMS structure with a group named `UV Signals` and channels such as `UVA`, `UVB`, `UVC`, and `UVV`.
- If a file has additional UV channels, the app will include their energy density and peak irradiance too.
- If a field is missing from a file, the corresponding Excel cell is left blank and the `Read Status` column will help flag issues.
