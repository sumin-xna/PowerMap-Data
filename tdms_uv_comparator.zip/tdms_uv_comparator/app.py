from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

import pandas as pd
import streamlit as st

from core import extract_tdms_summary, make_excel_download, order_columns


def main() -> None:
    st.set_page_config(page_title="TDMS UV Output Comparator", layout="wide")
    st.title("TDMS UV Output Comparator")
    st.write(
        "Drop one or more PowerMAP/TDMS files. The app extracts identifying metadata, "
        "notes, calibration and measurement dates, serial number, and UV output metrics, "
        "then exports one combined Excel comparison sheet."
    )

    uploaded_files = st.file_uploader(
        "Drop TDMS files here",
        type=["tdms"],
        accept_multiple_files=True,
    )

    if not uploaded_files:
        st.info("Upload TDMS files to begin.")
        return

    rows: List[Dict[str, Any]] = []
    channel_rows: List[Dict[str, Any]] = []
    errors: List[str] = []

    with st.spinner("Reading TDMS files..."):
        for uploaded_file in uploaded_files:
            try:
                row, details = extract_tdms_summary(uploaded_file)
                rows.append(row)
                channel_rows.extend(details)
            except Exception as exc:
                errors.append(f"{uploaded_file.name}: {exc}")
                rows.append(
                    {
                        "File Name": uploaded_file.name,
                        "TDMS Name": Path(uploaded_file.name).stem,
                        "Read Status": f"ERROR: {exc}",
                    }
                )

    summary_df = order_columns(pd.DataFrame(rows))
    channel_df = pd.DataFrame(channel_rows)

    ok_count = int((summary_df.get("Read Status", pd.Series(dtype=str)) == "OK").sum()) if "Read Status" in summary_df else len(summary_df)
    st.subheader("Comparison table")
    col1, col2, col3 = st.columns(3)
    col1.metric("Files read", len(uploaded_files))
    col2.metric("Parsed successfully", ok_count)
    col3.metric("Files with errors", len(errors))

    st.dataframe(summary_df, use_container_width=True, hide_index=True)

    excel_bytes = make_excel_download(summary_df)
    st.download_button(
        label="Download Excel comparison",
        data=excel_bytes,
        file_name="tdms_uv_comparison.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )

    with st.expander("Channel-by-channel details"):
        if channel_df.empty:
            st.write("No UV channel details found.")
        else:
            st.dataframe(channel_df, use_container_width=True, hide_index=True)

    if errors:
        with st.expander("Read errors"):
            for error in errors:
                st.error(error)


if __name__ == "__main__":
    main()
