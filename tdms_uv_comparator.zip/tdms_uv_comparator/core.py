from __future__ import annotations

import os
import re
import tempfile
from collections import OrderedDict
from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import pandas as pd
from nptdms import TdmsFile


# Channels normally produced by PowerMAP II TDMS files.
PREFERRED_UV_CHANNEL_ORDER = ["UVA", "UVB", "UVC", "UVV"]

BASE_COLUMNS = [
    "File Name",
    "TDMS Name",
    "Serial Number",
    "Calibration Date",
    "Date of Measurement",
    "Notes",
    "Model",
    "Unit Type",
    "Range",
    "UV Sample Rate Hz",
]

OPTIONAL_METADATA_COLUMNS = [
    "Board Temperature",
    "Battery Voltage",
    "Firmware Version",
    "PM2 Firmware Ver",
    "TC Used",
]


def clean_column_name(text: str) -> str:
    """Make a channel name safe and readable for column headings."""
    text = str(text).strip()
    text = re.sub(r"\s+", " ", text)
    return text


def get_property_case_insensitive(properties: Dict[str, Any], *names: str, default: Any = None) -> Any:
    """Get a TDMS property even if casing/spaces differ slightly."""
    if not properties:
        return default
    normalized = {str(k).lower().strip(): k for k in properties.keys()}
    for name in names:
        key = normalized.get(str(name).lower().strip())
        if key is not None:
            return properties.get(key)
    return default


def value_to_excel_safe(value: Any) -> Any:
    """Convert numpy/scalar TDMS values to values pandas/XlsxWriter can safely export."""
    if value is None:
        return None
    if isinstance(value, np.datetime64):
        return pd.to_datetime(value).to_pydatetime()
    if isinstance(value, np.generic):
        return value.item()
    return value


def parse_possible_date(value: Any) -> Any:
    """Parse date-like strings where possible; otherwise preserve original value."""
    value = value_to_excel_safe(value)
    if value is None or value == "":
        return None
    if isinstance(value, (datetime, pd.Timestamp)):
        return pd.to_datetime(value).to_pydatetime()
    parsed = pd.to_datetime(value, errors="coerce")
    if pd.notna(parsed):
        return parsed.to_pydatetime()
    return value


def tdms_from_uploaded_file(uploaded_file) -> TdmsFile:
    """nptdms reads most reliably from a real file path, so use a temp file."""
    suffix = Path(uploaded_file.name).suffix or ".tdms"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(uploaded_file.getbuffer())
        tmp_path = tmp.name
    try:
        return TdmsFile.read(tmp_path)
    finally:
        try:
            os.remove(tmp_path)
        except OSError:
            pass


def find_uv_group(tdms: TdmsFile):
    """Find the UV signal group. Prefer a group named 'UV Signals', but fall back to a group with UV channels."""
    groups = list(tdms.groups())
    for group in groups:
        if group.name.strip().lower() == "uv signals":
            return group
    for group in groups:
        channel_names = {ch.name.strip().upper() for ch in group.channels()}
        if channel_names.intersection(PREFERRED_UV_CHANNEL_ORDER):
            return group
    return None


def extract_tdms_summary(uploaded_file) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """Extract one comparison row plus a channel-level detail list from one TDMS file."""
    tdms = tdms_from_uploaded_file(uploaded_file)
    props = dict(tdms.properties)

    row: Dict[str, Any] = OrderedDict()
    row["File Name"] = uploaded_file.name
    row["TDMS Name"] = get_property_case_insensitive(props, "name") or Path(uploaded_file.name).stem
    row["Serial Number"] = value_to_excel_safe(get_property_case_insensitive(props, "Serial Number"))
    row["Calibration Date"] = parse_possible_date(get_property_case_insensitive(props, "Calibration Date"))
    row["Date of Measurement"] = parse_possible_date(get_property_case_insensitive(props, "Date & Time", "Date and Time", "Measurement Date"))
    row["Notes"] = value_to_excel_safe(get_property_case_insensitive(props, "Notes"))
    row["Model"] = value_to_excel_safe(get_property_case_insensitive(props, "Model"))
    row["Unit Type"] = value_to_excel_safe(get_property_case_insensitive(props, "Unit Type"))
    row["Range"] = value_to_excel_safe(get_property_case_insensitive(props, "Range"))
    row["UV Sample Rate Hz"] = value_to_excel_safe(get_property_case_insensitive(props, "sample_rate", "Sample Rate"))

    row["Board Temperature"] = value_to_excel_safe(get_property_case_insensitive(props, "Board Temperature"))
    row["Battery Voltage"] = value_to_excel_safe(get_property_case_insensitive(props, "Battery Voltage"))
    row["Firmware Version"] = value_to_excel_safe(get_property_case_insensitive(props, "Firmware Version"))
    row["PM2 Firmware Ver"] = value_to_excel_safe(get_property_case_insensitive(props, "PM2 Firmware Ver"))
    row["TC Used"] = value_to_excel_safe(get_property_case_insensitive(props, "TC_used", "TC Used"))

    channel_details: List[Dict[str, Any]] = []
    uv_group = find_uv_group(tdms)
    if uv_group is None:
        row["Read Status"] = "No UV Signals group found"
        return row, channel_details

    # Extract all UV channels available in the file.
    for channel in uv_group.channels():
        channel_name = clean_column_name(channel.name).upper()
        channel_props = dict(channel.properties)
        energy_density = value_to_excel_safe(
            get_property_case_insensitive(channel_props, "Energy Density", "Energy density")
        )
        peak_irradiance = value_to_excel_safe(
            get_property_case_insensitive(channel_props, "Peak Irradiance", "Peak irradiance")
        )

        # Requested comparison metrics in wide format.
        row[f"{channel_name} Energy Density (mJ/cm^2)"] = energy_density
        row[f"{channel_name} Peak Irradiance (mW/cm^2)"] = peak_irradiance

        # Diagnostics for the on-screen detail view.
        wf_increment = value_to_excel_safe(get_property_case_insensitive(channel_props, "wf_increment"))
        wf_samples = value_to_excel_safe(get_property_case_insensitive(channel_props, "wf_samples"))
        peak_time_s = None
        try:
            data = np.asarray(channel[:], dtype=float)
            if data.size and wf_increment:
                peak_time_s = float(np.nanargmax(data) * float(wf_increment))
        except Exception:
            peak_time_s = None

        channel_details.append(
            {
                "File Name": uploaded_file.name,
                "TDMS Name": row["TDMS Name"],
                "Channel": channel_name,
                "Energy Density (mJ/cm^2)": energy_density,
                "Peak Irradiance (mW/cm^2)": peak_irradiance,
                "Peak Time (s)": peak_time_s,
                "Samples": wf_samples,
                "Waveform Increment (s)": wf_increment,
            }
        )

    row["Read Status"] = "OK"
    return row, channel_details


def order_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Put metadata first, then UV channels in UVA/UVB/UVC/UVV order, then anything else."""
    cols = list(df.columns)
    ordered = [c for c in BASE_COLUMNS if c in cols]

    for channel in PREFERRED_UV_CHANNEL_ORDER:
        for metric in ["Energy Density (mJ/cm^2)", "Peak Irradiance (mW/cm^2)"]:
            col = f"{channel} {metric}"
            if col in cols:
                ordered.append(col)

    # Other UV channels, if present.
    remaining_metric_cols = [
        c
        for c in cols
        if c not in ordered
        and ("Energy Density" in c or "Peak Irradiance" in c)
    ]
    ordered.extend(sorted(remaining_metric_cols))

    ordered.extend([c for c in OPTIONAL_METADATA_COLUMNS if c in cols and c not in ordered])
    if "Read Status" in cols:
        ordered.append("Read Status")

    ordered.extend([c for c in cols if c not in ordered])
    return df[ordered]


def make_excel_download(summary_df: pd.DataFrame) -> bytes:
    """Create a polished one-sheet Excel comparison file."""
    output = BytesIO()
    with pd.ExcelWriter(
        output,
        engine="xlsxwriter",
        datetime_format="yyyy-mm-dd hh:mm:ss",
        date_format="yyyy-mm-dd",
    ) as writer:
        sheet_name = "TDMS Comparison"
        summary_df.to_excel(writer, sheet_name=sheet_name, index=False)

        workbook = writer.book
        worksheet = writer.sheets[sheet_name]

        header_fmt = workbook.add_format(
            {
                "bold": True,
                "text_wrap": True,
                "valign": "top",
                "border": 1,
            }
        )
        number_fmt = workbook.add_format({"num_format": "0.0000"})
        date_fmt = workbook.add_format({"num_format": "yyyy-mm-dd"})
        datetime_fmt = workbook.add_format({"num_format": "yyyy-mm-dd hh:mm:ss"})
        notes_fmt = workbook.add_format({"text_wrap": True, "valign": "top"})

        for col_idx, column in enumerate(summary_df.columns):
            worksheet.write(0, col_idx, column, header_fmt)
            series = summary_df[column]
            max_len = max([len(str(column))] + [len(str(x)) for x in series.dropna().head(200)])
            width = min(max(max_len + 2, 12), 60)

            if column == "Notes":
                worksheet.set_column(col_idx, col_idx, 55, notes_fmt)
            elif "Date" in column:
                fmt = datetime_fmt if column == "Date of Measurement" else date_fmt
                worksheet.set_column(col_idx, col_idx, max(width, 18), fmt)
            elif "Energy Density" in column or "Peak Irradiance" in column or "Voltage" in column or "Temperature" in column:
                worksheet.set_column(col_idx, col_idx, max(width, 16), number_fmt)
            else:
                worksheet.set_column(col_idx, col_idx, width)

        worksheet.freeze_panes(1, 0)
        if len(summary_df) > 0 and len(summary_df.columns) > 0:
            worksheet.autofilter(0, 0, len(summary_df), len(summary_df.columns) - 1)
        worksheet.set_landscape()
        worksheet.fit_to_pages(1, 0)

    return output.getvalue()
